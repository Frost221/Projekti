
///  class
class MedicMain {
    String Medic0;
    String Medic1;
    String Medic2;
    String Medic3;
    String Medic4;
    String Medic5;
    String Medic6;
    String Medic7;
    String Medic8;
    String Medic9;

    public MedicMain(String Medic0, String Medic1, String Medic2,
                     String Medic3, String Medic4, String Medic5,
                     String Medic6,String Medic7,String Medic8,
                     String Medic9) {


        this.Medic0 = Medic0;
        this.Medic1 = Medic1;
        this.Medic2 = Medic2;
        this.Medic3 = Medic3;
        this.Medic4 = Medic4;
        this.Medic5 = Medic5;
        this.Medic6 = Medic6;
        this.Medic7 = Medic7;
        this.Medic8 = Medic8;
        this.Medic9=Medic9;
    }

    ////// get method
    public String getMedic0() {
        return Medic0;
    }

    public String getMedic1() {
        return Medic1;
    }

    public String getMedic2() {
        return Medic3;
    }

    public String getMedic3() {
        return Medic3;
    }

    public String getMedic4() {
        return Medic4;
    }

    public String getMedic5() {
        return Medic5;
    }

    public String getMedic6() {
        return Medic6;
    }
    public String getMedic7() {
        return Medic7;
    }
    public String getMedic8() {
        return Medic8;
    }
    public String getMedic9() {
        return Medic9;
    }
}
//////  inheritance
class Stocks extends MedicMain {





    private String startMethod = "";

    public Stocks() {
        this("");
    }

    public Stocks(String method) {
        super("contains medicine:",
                "-Voltaren-5kom",
                "-Lupocet-6kom",
                "-Dermazin-3kom",
                "-Ibuprofen-4kom",
                "-Rojazol-2kom",
                "-Maxitrol-3kom",
                "-Betrion-7kom",
                "-Kapi-9kom",
                "medical gloves");
        this.startMethod = method;
    }





    public void display() {
        System.out.println("Small company medic:office number 01");

        System.out.println(super.getMedic1());
        System.out.println(super.getMedic2());
        System.out.println(super.getMedic3());
        System.out.println(super.getMedic4());
        System.out.println(super.getMedic5());
        System.out.println(super.getMedic6());
        System.out.println(super.getMedic7());
        System.out.println(super.getMedic8());

        System.out.println("Small company medic:office number 02");
        System.out.println(super.getMedic2());
        System.out.println(super.getMedic3());
        System.out.println(super.getMedic4());

        System.out.println("Small company medic:office number 03");
        System.out.println(super.getMedic3());
        System.out.println(super.getMedic4());
        System.out.println(super.getMedic5());

        System.out.println("Next company medic:office number 01:");
        System.out.println(super.getMedic2());
        System.out.println(super.getMedic9());
        System.out.println(super.getMedic2());
        System.out.println(super.getMedic1());

        System.out.println("Next company medic:office number 02:");
        System.out.println(super.getMedic6());
        System.out.println(super.getMedic7());
        System.out.println(super.getMedic8());

        System.out.println("Next company medic:office number 03:");
        System.out.println(super.getMedic4());
        System.out.println(super.getMedic5());
        System.out.println(super.getMedic6());
    }



}
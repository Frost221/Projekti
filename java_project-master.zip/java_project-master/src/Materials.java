

///  class
class MaterialsMain {

    String Materials0;


    String Materials2;

    String Materials3;

    String Materials4;

    String Materials5;

    String Materials6;

    String Materials7;


    public MaterialsMain(String Materials0, String Materials2,
                         String Materials3, String Materials4,
                         String Materials5, String Materials6,
                         String Materials7) {

        this.Materials0 = Materials0;


        this.Materials2 = Materials2;

        this.Materials3 = Materials3;

        this.Materials4 = Materials4;

        this.Materials5 = Materials5;

        this.Materials6 = Materials6;

        this.Materials7 = Materials7;


    }


    ////// get method
    public String getMaterials0() {
        return Materials0;
    }


    public String getMaterials2() {
        return Materials2;
    }

    public String getMaterials3() {
        return Materials3;
    }

    public String getMaterials4() {
        return Materials4;
    }

    public String getMaterials5() {
        return Materials5;
    }

    public String getMaterials6() {
        return Materials6;
    }

    public String getMaterials7() {
        return Materials7;
    }
}



//////  inheritance
class MaterialStocks extends MaterialsMain {





    private String startMethod = "ss";

    public MaterialStocks() {
        this("ss");
    }

    public MaterialStocks(String method) {
        super("contains materials:",
                "water",
                "dust",
                "aloe vera",
                "acid",
                "Parafin",
                "coconut milk");
        this.startMethod = method;
    }





    public void display() {


        System.out.println("Small company materials:office 01");
        System.out.println(super.getMaterials2());
        System.out.println(super.getMaterials3());
        System.out.println(super.getMaterials4());
        System.out.println(super.getMaterials5());
        System.out.println(super.getMaterials6());
        System.out.println(super.getMaterials7());

        System.out.println("Small company materials:office 02");
        System.out.println(super.getMaterials3());
        System.out.println(super.getMaterials4());
        System.out.println(super.getMaterials5());
        System.out.println("Small company materials:office 03");

        System.out.println(super.getMaterials4());
        System.out.println(super.getMaterials5());
        System.out.println(super.getMaterials6());

        System.out.println("Next company materials:office01:");
        System.out.println(super.getMaterials2());
        System.out.println(super.getMaterials3());

        System.out.println("Next company materials:office02:");
        System.out.println(super.getMaterials3());
        System.out.println(super.getMaterials4());
        System.out.println(super.getMaterials5());

        System.out.println("Next company materials:office03:");
        System.out.println(super.getMaterials2());
        System.out.println(super.getMaterials3());
        System.out.println(super.getMaterials4());


    }



}
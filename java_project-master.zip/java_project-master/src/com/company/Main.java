package com.company;

public class Main {


    public static void main(String[] args) {


        Stocks Stocksmedic = new Stocks();



        Stocksmedic.display();

        MaterialStocks Stocksme = new MaterialStocks();



        Stocksme.display();
    }
}
